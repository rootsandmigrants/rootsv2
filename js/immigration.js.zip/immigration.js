document.addEventListener("DOMContentLoaded", () => {
  class ImmigrationMap {
    constructor(containerId, sliderId, sliderTicksId, year = "1850") {
      this.containerId = containerId;
      this.sliderId = sliderId;
      this.sliderTicksId = sliderTicksId;
      this.currentYear = year;
      this.countryCoordinates = {};
      this.selectedStateFeature = null; // 🔸 Track clicked state for reuse
      this.selectedStateName = null; // 🔸 Added to track state name for easier matching
      this.enabledYears = []; // ✅ Store valid years with data

      this.map = new maplibregl.Map({
        container: this.containerId,
        style: {
          version: 8,
          sources: {
            esriWorldPhysical: {
              type: "raster",
              tiles: [
                "https://server.arcgisonline.com/ArcGIS/rest/services/World_Physical_Map/MapServer/tile/{z}/{y}/{x}",
              ],
              tileSize: 256,
              attribution:
                '<a href="https://www.esri.com/" target="_blank">Esri</a> | <a href="https://www.nhgis.org/" target="_blank">IPUMS NHGIS</a>',
            },
          },
          glyphs:
            "https://geosocial.geography.uiowa.edu/fonts/glyphs/{fontstack}/{range}.pbf",

          layers: [
            {
              id: "esriWorldPhysical-layer",
              type: "raster",
              source: "esriWorldPhysical",
              minzoom: 0,
              maxzoom: 24,
              paint: { "raster-opacity": 0.3 },
            },
          ],
        },

        center: [-98.35, 39.5],
        zoom: 3,
        // renderWorldCopies: false,
      });

      this.initializeControls();
      this.loadCountryCoordinates();
      this.generateSliderTicks();
      this.initializeMap();
    }

    initializeControls() {
      this.map.addControl(new maplibregl.NavigationControl(), "bottom-right");
      this.map.addControl(
        new maplibregl.ScaleControl({ maxWidth: 100, unit: "metric" }),
        "bottom-left"
      );
      this.addCustomZoomToExtentButton();
    }

    addCustomZoomToExtentButton() {
      const button = document.createElement("button");
      button.className = "custom-zoom-to-extent-button-immigration";
      button.innerHTML = '<img src="img/extent.png" alt="Zoom to Extent">';

      const tooltip = document.createElement("div");
      tooltip.className = "custom-zoom-to-extent-tooltip-immigration";
      tooltip.textContent = "Zoom to Extent";

      button.appendChild(tooltip);
      button.addEventListener("click", () => {
        this.map.easeTo({
          center: [-98.35, 39.5],
          zoom: 4,
          pitch: 0,
          bearing: 0,
          essential: true,
        });
      });

      this.map.getContainer().appendChild(button);
    }

    loadCountryCoordinates() {
      fetch("assets/countryCoordinates.json")
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.json();
        })
        .then((data) => {
          this.countryCoordinates = data;
          console.log("Loaded country coordinates:", this.countryCoordinates);
        })
        .catch((error) => {
          console.error("Error loading country coordinates:", error);
        });
    }
    async loadLimitMetadata() {
      try {
        const response = await fetch("assets/immigration/limit.json");
        if (!response.ok) throw new Error("Failed to load metadata.");
        this.yearMetadata = await response.json();
        console.log("Limit metadata loaded:", this.yearMetadata);
      } catch (error) {
        console.error("Error loading limit metadata:", error);
        this.yearMetadata = {};
      }
    }

    async loadStateData(year) {
      const stateGeoJsonUrl = `assets/immigration/FOREIGN_${year}.geojson`;
      try {
        const response = await fetch(stateGeoJsonUrl);
        const geoJson = await response.json();

        if (!geoJson || geoJson.type !== "FeatureCollection") {
          console.error("Invalid GeoJSON data:", geoJson);
          return { geoJson, labels: null };
        }

        const labelFeatures = geoJson.features.map((feature) => {
          const stateCentroid = turf.centroid(feature).geometry.coordinates;
          const stateName =
            feature.properties.STATENAM ||
            feature.properties.LABEL ||
            "Unknown";

          return {
            type: "Feature",
            geometry: {
              type: "Point",
              coordinates: stateCentroid,
            },
            properties: { label: stateName },
          };
        });

        return {
          geoJson,
          labels: {
            type: "FeatureCollection",
            features: labelFeatures,
          },
        };
      } catch (error) {
        console.error("Error loading state data:", error);
        return {
          geoJson: { type: "FeatureCollection", features: [] },
          labels: null,
        };
      }
    }

    generateFlowsForState(stateFeature) {
      const stateCentroid = turf.centroid(stateFeature).geometry.coordinates;
      const flowFeatures = [];
      const circleFeatures = [];

      Object.entries(stateFeature.properties)
        .filter(([key, value]) => this.countryCoordinates[key] && value > 0)
        .forEach(([country, people]) => {
          people = Number(people); // 👈 force numeric value!

          const countryCoords = this.countryCoordinates[country];

          // Create migration flow line
          const line = turf.lineString([countryCoords, stateCentroid]);
          flowFeatures.push({
            type: "Feature",
            geometry: line.geometry,
            properties: { people },
          });

          // 🔹 Ensure circle size scales proportionally
          const radius = this.calculateProportionalSize(people);

          circleFeatures.push({
            type: "Feature",
            geometry: {
              type: "Point",
              coordinates: countryCoords, // Centered at the country
            },
            properties: {
              people,
              country,
              radius, // Store radius value
            },
          });
        });

      return { flowFeatures, circleFeatures };
    }

    calculateLegendSize(value) {
      if (value <= 0) return 3; // Smallest circle to prevent zero size

      const minSize = 5; // Reduced minimum legend circle size
      const maxSize = 40; // Reduced maximum legend circle size for UI balance
      const minValue = 1;
      const maxValue = 500000; // Match dataset scale

      // Logarithmic scaling for smoother size differences
      const scale =
        (Math.log(value + 1) - Math.log(minValue + 1)) /
        (Math.log(maxValue + 1) - Math.log(minValue + 1));

      return minSize + scale * (maxSize - minSize);
    }

    calculateProportionalSize(value) {
      const minSize = 2; // Minimum circle size
      const maxSize = 40; // Maximum circle size
      const minValue = 1;
      const maxValue = 500000; // Adjust based on dataset

      // Ensure value is always at least 1 (to avoid log(0) errors)
      value = Math.max(value, 1);

      // 🔥 Logarithmic Scaling Formula
      const scaledSize =
        (Math.log(value) - Math.log(minValue)) /
        (Math.log(maxValue) - Math.log(minValue));

      return minSize + scaledSize * (maxSize - minSize);
    }

    updateLegend() {
      const legendValues = [5, 50, 500, 5000, 50000]; // 5 thresholds = 5 circles

      legendValues.forEach((value, index) => {
        const size = this.calculateLegendSize(value);

        const circle = document.getElementById(`legend-circle-${index + 1}`);
        const text = document.getElementById(`legend-text-${index + 1}`);

        if (circle) {
          circle.style.width = `${size}px`;
          circle.style.height = `${size}px`;
          circle.style.border = "1px solid #000";
          circle.style.backgroundColor = "#2171b5";
          circle.style.marginBottom = `${Math.max(size / 2, 20)}px`;
        }

        if (text) {
          text.style.marginTop = "10px";
          if (index === 0) {
            text.textContent = "< 5 people";
          } else if (index === legendValues.length - 1) {
            text.textContent = `${value}+ people`;
          } else {
            const lower = legendValues[index - 1];
            text.textContent = `${lower}–${value - 1} people`;
          }
        }
      });

      document.getElementById("legend-year-value").textContent =
        this.currentYear;
    }

    updateHighlight(feature) {
      if (this.map.getSource("state-highlight")) {
        const cloned = JSON.parse(JSON.stringify(feature));
        this.map.getSource("state-highlight").setData({
          type: "FeatureCollection",
          features: [cloned],
        });
      }
    }

    clearHighlight() {
      if (this.map.getSource("state-highlight")) {
        this.map.getSource("state-highlight").setData({
          type: "FeatureCollection",
          features: [],
        });
      }
    }

    updateFlows(stateFeature) {
      this.currentState =
        stateFeature.properties.STATENAM ||
        stateFeature.properties.LABEL ||
        "Unknown State";

      const { flowFeatures, circleFeatures } =
        this.generateFlowsForState(stateFeature);

      if (flowFeatures.length === 0) {
        showModal(); // Show modal if no data is available
        return;
      }

      // 🔹 Update migration flow lines dynamically
      if (this.map.getSource("flows")) {
        this.map.getSource("flows").setData({
          type: "FeatureCollection",
          features: flowFeatures,
        });
      } else {
        console.warn("Flows source not found, skipping update.");
      }

      // 🔹 Update proportional circles with calculated radius
      if (this.map.getSource("proportional-circles")) {
        this.map.getSource("proportional-circles").setData({
          type: "FeatureCollection",
          features: circleFeatures.map((feature) => ({
            ...feature,
            properties: {
              ...feature.properties,
              radius: this.calculateProportionalSize(
                feature.properties.people || 1
              ), // Ensure size is set correctly
            },
          })),
        });

        // 🛠 Force MapLibre to recognize radius from `properties.radius`
        this.map.setPaintProperty("circle-layer", "circle-radius", [
          "get",
          "radius",
        ]);
      } else {
        console.warn("Proportional circles source not found, skipping update.");
      }

      // 🔥 Ensure the legend matches the updated data
      this.updateLegend();

      console.log(`🔄 Updated migration data for ${this.currentState}`);
    }

    clearFlows() {
      if (this.map.getSource("flows")) {
        this.map.getSource("flows").setData({
          type: "FeatureCollection",
          features: [],
        });
      }

      if (this.map.getSource("proportional-circles")) {
        this.map.getSource("proportional-circles").setData({
          type: "FeatureCollection",
          features: [],
        });
      }

      if (this.map.getSource("arrowheads")) {
        this.map.getSource("arrowheads").setData({
          type: "FeatureCollection",
          features: [],
        });
      }
    }

    async initializeMap() {
      this.map.on("load", async () => {
        console.log("Map fully loaded, now loading immigration data...");
        await this.loadLimitMetadata(); // ✅ LOAD METADATA FIRST

        // // 🔹 Load Continents Data
        // const africaGeoJson = await fetch("assets/continents/AFRICA.json").then(
        //   (res) => res.json()
        // );
        // const southAmericaGeoJson = await fetch(
        //   "assets/continents/southamerica.json"
        // ).then((res) => res.json());
        // const centralAmericaGeoJson = await fetch(
        //   "assets/continents/centralAmerica.geojson"
        // ).then((res) => res.json());

        // //  Add Africa Source & Layer
        // this.map.addSource("africa", { type: "geojson", data: africaGeoJson });
        // this.map.addLayer({
        //   id: "africa-layer",
        //   type: "fill",
        //   source: "africa",
        //   paint: { "fill-color": "#D3D3D3", "fill-opacity": 1 },
        // });
        // this.map.addLayer({
        //   id: "africa-borders",
        //   type: "line",
        //   source: "africa",
        //   paint: { "line-color": "#000000", "line-width": 0.8 },
        // });

        // //  Add South America Source & Layer
        // this.map.addSource("southamerica", {
        //   type: "geojson",
        //   data: southAmericaGeoJson,
        // });
        // this.map.addLayer({
        //   id: "southamerica-layer",
        //   type: "fill",
        //   source: "southamerica",
        //   paint: { "fill-color": "#D3D3D3", "fill-opacity": 1 },
        // });
        // this.map.addLayer({
        //   id: "southamerica-borders",
        //   type: "line",
        //   source: "southamerica",
        //   paint: { "line-color": "#000000", "line-width": 1 },
        // });

        // //  Add Central America Source & Layer
        // this.map.addSource("centralAme", {
        //   type: "geojson",
        //   data: centralAmericaGeoJson,
        // });
        // this.map.addLayer({
        //   id: "central-layer",
        //   type: "fill",
        //   source: "centralAme",
        //   paint: { "fill-color": "#D3D3D3", "fill-opacity": 1 },
        // });
        // this.map.addLayer({
        //   id: "central-borders",
        //   type: "line",
        //   source: "centralAme",
        //   paint: { "line-color": "#000000", "line-width": 0.8 },
        // });

        // console.log("Africa, Central America & South America layers loaded.");

        //  Load Initial State Data for Default Year
        const { geoJson, labels } = await this.loadStateData(this.currentYear);

        this.map.addSource("states", { type: "geojson", data: geoJson });
        // ✅ Initialize the legend
        this.updateLegend();
        const warningFlag = document.getElementById("legend-warning-flag");
        const metadata = this.yearMetadata[this.currentYear];

        if (metadata && (metadata.raceLimited || metadata.sample)) {
          warningFlag.title = metadata.note;
          warningFlag.style.display = "inline";
        } else {
          warningFlag.style.display = "none";
        }

        this.map.addLayer({
          id: "state-boundaries",
          type: "fill",
          source: "states",
          paint: { "fill-color": "transparent", "fill-opacity": 1 },
        });
        this.map.addLayer({
          id: "state-borders",
          type: "line",
          source: "states",
          paint: { "line-color": "#000000", "line-width": 0.2 },
        });

        //  Add & Update Labels
        if (labels && labels.features.length > 0) {
          if (this.map.getSource("state-labels")) {
            this.map.getSource("state-labels").setData(labels);
            console.log("Updated state labels.");
          } else {
            this.map.addSource("state-labels", {
              type: "geojson",
              data: labels,
            });
            this.map.addLayer({
              id: "state-labels-layer",
              type: "symbol",
              source: "state-labels",
              layout: {
                "text-field": ["get", "label"],
                "text-font": ["Metropolis-Bold"],
                "text-size": 10,
                "text-anchor": "center",
              },
              paint: {
                "text-color": "#000",
                "text-halo-color": "#FFF",
                "text-halo-width": 1,
              },
            });
          }
        } else {
          console.warn("No labels found for the selected year.");
        }
        // 🔹 Add highlight source and layer
        this.map.addSource("state-highlight", {
          type: "geojson",
          data: { type: "FeatureCollection", features: [] },
        });

        this.map.addLayer(
          {
            id: "state-highlight-layer",
            type: "line",
            source: "state-highlight",
            paint: {
              "line-color": "#FF5733",
              "line-width": 3,
              "line-dasharray": [2, 2],
              "line-opacity": 1,
            },
          },
          "state-borders"
        ); // ✅ Insert above fill/border layers

        //  Add Flow Lines & Arrows
        this.map.addSource("flows", {
          type: "geojson",
          data: { type: "FeatureCollection", features: [] },
        });
        this.map.addLayer({
          id: "flow-lines",
          type: "line",
          source: "flows",
          layout: {
            "line-cap": "round",
            "line-join": "round",
          },
          paint: {
            "line-color": "#f0f2f2", // White lines
            "line-width": 1.5,
            "line-opacity": 0.8,
            "line-blur": 0.2,
          },
        });

        this.map.addSource("proportional-circles", {
          type: "geojson",
          data: { type: "FeatureCollection", features: [] },
        });

        this.map.addLayer({
          id: "circle-layer",
          type: "circle",
          source: "proportional-circles",
          paint: {
            "circle-radius": [
              "interpolate",
              ["linear"],
              ["log10", ["get", "people"]],
              Math.log10(1),
              2,
              Math.log10(100),
              4,
              Math.log10(1000),
              6,
              Math.log10(500000),
              8,
            ],
            "circle-color": "#2171b5", // ✅ fixed blue color
            "circle-opacity": 1,
            "circle-stroke-width": 1,
            "circle-stroke-color": "#000",
          },
        });

        // Create a popup but don't add it to the map yet
        const popup = new maplibregl.Popup({
          closeButton: false,
          closeOnClick: false,
        });
        this.map.on("mouseenter", "circle-layer", (e) => {
          this.map.getCanvas().style.cursor = "pointer"; // Change cursor to pointer

          if (!e.features.length) return;

          const feature = e.features[0];
          const country = feature.properties.country || "Unknown Country";
          const people = feature.properties.people || 0;

          // Ensure the correct state name is used
          const state = this.currentState || "Unknown State";
          const year = this.currentYear || "Unknown Year";

          // Check singular/plural for "person" vs. "people"
          const peopleText = people === 1 ? "person" : "people";

          const peopleFormatted = people.toLocaleString("en-US");

          const description = `<strong>${peopleFormatted}</strong> ${peopleText} immigrated to <strong>${state}</strong> from <strong>${country}</strong> in <strong>${year}</strong>.`;

          popup.setLngLat(e.lngLat).setHTML(description).addTo(this.map);
        });

        this.map.on("mouseleave", "circle-layer", () => {
          this.map.getCanvas().style.cursor = "";
          popup.remove(); // Remove popup on mouse leave
        });

        this.map.addSource("arrowheads", {
          type: "geojson",
          data: { type: "FeatureCollection", features: [] },
        });
        this.map.addLayer({
          id: "arrowheads",
          type: "symbol",
          source: "arrowheads",
          layout: {
            "icon-image": "arrow",
            "icon-size": 0.6,
            "icon-rotate": ["get", "bearing"],
            "icon-allow-overlap": true,
          },
        });

        // Handle State Click Events
        this.map.on("click", "state-boundaries", (e) => {
          // First, clear any previous selection
          this.clearFlows();
          this.clearHighlight();

          const clickedFeature = e.features[0];
          const clickedStateName =
            clickedFeature.properties.STATENAM ||
            clickedFeature.properties.LABEL;

          // 🔸 Store the name for easy matching after year change
          this.selectedStateName = clickedStateName;

          // Highlight the clicked feature directly - don't need to find in geojson
          this.updateHighlight(clickedFeature);

          // For flows, we still need the complete feature data
          const geojson = this.map.getSource("states")._data || {
            features: [],
          };

          const matched = geojson.features.find(
            (f) =>
              f.properties.STATENAM === clickedStateName ||
              f.properties.LABEL === clickedStateName
          );

          if (!matched) {
            console.warn("Clicked state not found in current GeoJSON");
            showModal();
            return;
          }

          // ✅ Store latest version from current year
          this.selectedStateFeature = matched;

          // ✅ Update flows
          this.updateFlows(matched);

          console.log(`🖱️ Clicked and highlighted: ${clickedStateName}`);
        });
        const flag = document.getElementById("legend-warning-flag");
        flag.addEventListener("click", () => {
          const metadata = this.yearMetadata?.[this.currentYear];
          if (metadata && metadata.note) {
            const content = `
              <p>${metadata.note}</p>
              ${
                metadata.source
                  ? `<p style="margin-top: 10px; font-size: 0.9em; color: #666;"><strong>Source:</strong> ${metadata.source}</p>`
                  : ""
              }
            `;
            window.showInfoModal("Data Limitation", content);
          }
        });
      });

      // Update Data on Slider Input
      document
        .getElementById(this.sliderId)
        .addEventListener("input", async (event) => {
          const rawYear = parseInt(event.target.value);
          const slider = event.target;

          // 🔹 Snap only to the closest enabled year
          let snappedYear = this.enabledYears.reduce(
            (prev, curr) =>
              Math.abs(curr - rawYear) < Math.abs(prev - rawYear) ? curr : prev,
            this.enabledYears[0]
          );

          if (snappedYear !== rawYear) {
            slider.value = snappedYear; // Update UI
          }

          this.currentYear = snappedYear; // ✅ Show race/sample warning icon if needed
          const warningFlag = document.getElementById("legend-warning-flag");
          const metadata = this.yearMetadata[this.currentYear];

          if (metadata && (metadata.raceLimited || metadata.sample)) {
            warningFlag.title = metadata.note;
            warningFlag.style.display = "inline";
          } else {
            warningFlag.style.display = "none";
          }

          document.getElementById("legend-year").textContent = snappedYear;

          const { geoJson, labels } = await this.loadStateData(snappedYear);

          if (this.map.getSource("states")) {
            this.map.getSource("states").setData(geoJson);
          }

          if (this.map.getSource("state-labels")) {
            this.map.getSource("state-labels").setData(labels);
          }

          this.clearFlows();
          this.clearHighlight();

          if (this.selectedStateName) {
            const matched = geoJson.features.find(
              (f) =>
                f.properties.STATENAM === this.selectedStateName ||
                f.properties.LABEL === this.selectedStateName
            );

            if (matched) {
              this.selectedStateFeature = JSON.parse(JSON.stringify(matched));
              this.updateHighlight(matched);
              this.updateFlows(matched);
            } else {
              showModal();
              this.selectedStateFeature = null;
            }
          }

          // 🔹 Optional: Highlight active tick
          document.querySelectorAll(".slider-tick").forEach((tick) => {
            if (parseInt(tick.dataset.year) === snappedYear) {
              tick.style.backgroundColor = "#000";
              tick.style.height = "15px";
            } else {
              tick.style.backgroundColor = "black";
              tick.style.height = "10px";
            }
          });

          console.log(`Map updated for year: ${snappedYear}`);
        });
    }

    async generateSliderTicks() {
      const slider = document.getElementById(this.sliderId);
      const sliderTicksContainer = document.getElementById(this.sliderTicksId);
      sliderTicksContainer.innerHTML = "";
      this.enabledYears = []; // 🔹 Clear before rebuilding

      for (
        let year = parseInt(slider.min);
        year <= parseInt(slider.max);
        year += parseInt(slider.step)
      ) {
        const tickWrapper = document.createElement("div");
        tickWrapper.className = "slider-tick-wrapper";

        const tick = document.createElement("div");
        tick.className = "slider-tick";
        tick.dataset.year = year;

        const label = document.createElement("div");
        label.className = "slider-label";
        label.textContent = year;

        tickWrapper.appendChild(tick);
        tickWrapper.appendChild(label);
        sliderTicksContainer.appendChild(tickWrapper);

        const { geoJson } = await this.loadStateData(year);

        let hasFlows = false;
        for (const feature of geoJson.features) {
          const { flowFeatures } = this.generateFlowsForState(feature);
          if (flowFeatures.length > 0) {
            hasFlows = true;
            break;
          }
        }

        if (!hasFlows && year !== parseInt(this.currentYear)) {
          tick.classList.add("disabled-tick");
          tick.title = "No data available for this year";
          tick.style.opacity = "0.5";
          tick.style.cursor = "default";
          label.style.color = "#aaa";
          label.title = "No data available for this year";
        } else {
          this.enabledYears.push(year); // ✅ Track usable year
          tick.addEventListener("click", () => {
            slider.value = year;
            slider.dispatchEvent(new Event("input"));
          });
        }
      }
    }
  }

  window.ImmigrationMap = new ImmigrationMap(
    "mapImmigration",
    "slider-immigration",
    "slider-ticks-container"
  );
});
